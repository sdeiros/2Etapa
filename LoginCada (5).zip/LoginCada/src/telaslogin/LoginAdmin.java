/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package telaslogin;
import TelasERROR.ErroLogin;
import telaslogin.EsqueceusenhaAdmin;
import dao.AdmintD;
import factory.ConnectionFactory;
import java.awt.event.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import telasdeligação.TelaPrincipalAdmin;
import telasdeligação.Telaescolhelogin;
import telasplash.TelaSair;

/**
 *
 * @author aluno_iserj
 */
public class LoginAdmin extends javax.swing.JFrame {
    ConnectionFactory con = new ConnectionFactory();
      private Connection connection;
    
    
    
    

    /**
     * Creates new form NewJFrame
     */
    public LoginAdmin() {
        initComponents();
        
    }
    
   
    
    private void Login(){
        AdmintD dao = new AdmintD();
       if(!dao.CheckLogin(LoginAdminTxtF.getText(), SenhaAdminPssF.getText())) {
            new TelaPrincipalAdmin().setVisible(true);
        } else {
             new ErroLogin().setVisible(true);
            LoginAdminTxtF.setText("");
           SenhaAdminPssF.setText("");
        }

    
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        PainelVerde = new javax.swing.JPanel();
        PainelAmarelo = new javax.swing.JPanel();
        SenhaLB = new javax.swing.JLabel();
        LoginLB = new javax.swing.JLabel();
        IconUser = new javax.swing.JLabel();
        BemvindoLB = new javax.swing.JLabel();
        BotãoLogin = new javax.swing.JButton();
        BotãoSair = new javax.swing.JButton();
        EsqueceusuasenhaLB = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        LoginAdminTxtF = new javax.swing.JTextField();
        SenhaAdminPssF = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        IconVoltar = new javax.swing.JLabel();

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 186, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 26, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        PainelVerde.setBackground(new java.awt.Color(179, 42, 7));
        PainelVerde.setPreferredSize(new java.awt.Dimension(550, 314));
        PainelVerde.setLayout(null);

        PainelAmarelo.setBackground(new java.awt.Color(234, 125, 70));

        SenhaLB.setBackground(new java.awt.Color(51, 51, 51));
        SenhaLB.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        SenhaLB.setForeground(new java.awt.Color(51, 51, 51));
        SenhaLB.setText("Senha");

        LoginLB.setBackground(new java.awt.Color(102, 102, 102));
        LoginLB.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        LoginLB.setForeground(new java.awt.Color(51, 51, 51));
        LoginLB.setText("Login");

        IconUser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/logincad.png"))); // NOI18N

        BemvindoLB.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        BemvindoLB.setForeground(new java.awt.Color(255, 255, 255));
        BemvindoLB.setText("Bem-Vindo");

        BotãoLogin.setBackground(new java.awt.Color(234, 125, 70));
        BotãoLogin.setForeground(new java.awt.Color(51, 51, 51));
        BotãoLogin.setText("Login");
        BotãoLogin.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));
        BotãoLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotãoLoginMouseClicked(evt);
            }
        });
        BotãoLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotãoLoginActionPerformed(evt);
            }
        });

        BotãoSair.setBackground(new java.awt.Color(234, 125, 70));
        BotãoSair.setForeground(new java.awt.Color(51, 51, 51));
        BotãoSair.setText("Sair");
        BotãoSair.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(51, 51, 51), 1, true));
        BotãoSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotãoSairActionPerformed(evt);
            }
        });

        EsqueceusuasenhaLB.setBackground(new java.awt.Color(51, 51, 51));
        EsqueceusuasenhaLB.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        EsqueceusuasenhaLB.setForeground(new java.awt.Color(51, 51, 51));
        EsqueceusuasenhaLB.setText("Esqueceu sua senha ?");
        EsqueceusuasenhaLB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EsqueceusuasenhaLBMouseClicked(evt);
            }
        });

        jSeparator2.setForeground(new java.awt.Color(51, 51, 51));

        jSeparator3.setForeground(new java.awt.Color(51, 51, 51));

        LoginAdminTxtF.setBackground(new java.awt.Color(234, 125, 70));
        LoginAdminTxtF.setBorder(null);
        LoginAdminTxtF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginAdminTxtFActionPerformed(evt);
            }
        });

        SenhaAdminPssF.setBackground(new java.awt.Color(234, 125, 70));
        SenhaAdminPssF.setBorder(null);
        SenhaAdminPssF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SenhaAdminPssFActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PainelAmareloLayout = new javax.swing.GroupLayout(PainelAmarelo);
        PainelAmarelo.setLayout(PainelAmareloLayout);
        PainelAmareloLayout.setHorizontalGroup(
            PainelAmareloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PainelAmareloLayout.createSequentialGroup()
                .addGroup(PainelAmareloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PainelAmareloLayout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addGroup(PainelAmareloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SenhaLB)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SenhaAdminPssF, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PainelAmareloLayout.createSequentialGroup()
                                .addComponent(BotãoSair, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(61, 61, 61)
                                .addComponent(BotãoLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(PainelAmareloLayout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(PainelAmareloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LoginLB, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LoginAdminTxtF, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PainelAmareloLayout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addGroup(PainelAmareloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(BemvindoLB)
                            .addComponent(IconUser, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PainelAmareloLayout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addComponent(EsqueceusuasenhaLB, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(73, Short.MAX_VALUE))
        );
        PainelAmareloLayout.setVerticalGroup(
            PainelAmareloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PainelAmareloLayout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(IconUser)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BemvindoLB, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(LoginLB, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LoginAdminTxtF, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(SenhaLB)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(SenhaAdminPssF, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addComponent(EsqueceusuasenhaLB, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(PainelAmareloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotãoSair, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BotãoLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
        );

        PainelVerde.add(PainelAmarelo);
        PainelAmarelo.setBounds(360, 0, 450, 450);

        jLabel1.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-macho-de-configurações-de-admin-100 (1).png"))); // NOI18N
        PainelVerde.add(jLabel1);
        jLabel1.setBounds(70, 90, 120, 130);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Login Administrativo");
        PainelVerde.add(jLabel2);
        jLabel2.setBounds(60, 220, 190, 25);

        IconVoltar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/unnamed.png"))); // NOI18N
        IconVoltar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                IconVoltarMouseClicked(evt);
            }
        });
        PainelVerde.add(IconVoltar);
        IconVoltar.setBounds(0, 0, 24, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PainelVerde, javax.swing.GroupLayout.DEFAULT_SIZE, 800, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PainelVerde, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void BotãoSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotãoSairActionPerformed
        //Fechando tela de login
        LoginAdmin.this.dispose();
        
        //Chamndo a tela de saída
        new TelaSair().setVisible(true);
    }//GEN-LAST:event_BotãoSairActionPerformed

    private void BotãoLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotãoLoginActionPerformed
      String login;
      String senha;
      connection = con.getConnection();

      String sq = "select * from admin where login = ? and senha =?";
      PreparedStatement stmt;
        try {
            stmt = connection.prepareStatement(sq);
            stmt.setString(1,LoginAdminTxtF.getText());
            stmt.setString(2,SenhaAdminPssF.getText());
            
           ResultSet rs = stmt.executeQuery();
           
           
           if(rs.next()){
               login =(rs.getString("login"));
               senha =(rs.getString("senha"));
                new TelaPrincipalAdmin().setVisible(true);
                LoginAdmin.this.dispose();
           }else{
               new ErroLogin().setVisible(true);
               LoginAdminTxtF.setText("");
               SenhaAdminPssF.setText("");
           }
        } catch (SQLException ex) {
             new ErroLogin().setVisible(true);
            Logger.getLogger(LoginAdmin.class.getName()).log(Level.SEVERE, null, ex);
        }
     

    }//GEN-LAST:event_BotãoLoginActionPerformed

    private void BotãoLoginMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotãoLoginMouseClicked
        
    
       

    }//GEN-LAST:event_BotãoLoginMouseClicked

    private void LoginAdminTxtFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginAdminTxtFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LoginAdminTxtFActionPerformed

    private void EsqueceusuasenhaLBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EsqueceusuasenhaLBMouseClicked
          LoginAdmin.this.dispose(); 
          new EsqueceusenhaAdmin().setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_EsqueceusuasenhaLBMouseClicked

    private void SenhaAdminPssFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SenhaAdminPssFActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SenhaAdminPssFActionPerformed

    private void IconVoltarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IconVoltarMouseClicked
  LoginAdmin.this.dispose();   
    Telaescolhelogin Telaescolhelogin = new Telaescolhelogin();
    Telaescolhelogin.setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_IconVoltarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BemvindoLB;
    private javax.swing.JButton BotãoLogin;
    private javax.swing.JButton BotãoSair;
    private javax.swing.JLabel EsqueceusuasenhaLB;
    private javax.swing.JLabel IconUser;
    private javax.swing.JLabel IconVoltar;
    private javax.swing.JTextField LoginAdminTxtF;
    private javax.swing.JLabel LoginLB;
    private javax.swing.JPanel PainelAmarelo;
    private javax.swing.JPanel PainelVerde;
    private javax.swing.JPasswordField SenhaAdminPssF;
    private javax.swing.JLabel SenhaLB;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    // End of variables declaration//GEN-END:variables
}


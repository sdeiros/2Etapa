
package dao;

import factory.ConnectionFactory;
import java.awt.Image;
import java.awt.List;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import modelo.admin;
import java.sql.*;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
//Declaração de variaveis/

public class AdmintD {
     Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;

    private Connection connection;
    ArrayList<admin> lista = new ArrayList<>();
    Long id;
    String nomeong;
    String endereço;
    String email;
    String telefone;
    //Puxando metodo de conexão/

    public AdmintD() {
        this.connection = new ConnectionFactory().getConnection();

    }

    //Declarando string com uma query em MYSQL
    
    public void buscarimagem(JLabel LBfotousuario, String id) {
        String sql = "select * from admin where id = ? ";

        try {
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setString(1, id);
            ResultSet res = stmt.executeQuery();

        if (res.next()) {
                Blob blob = (Blob) res.getBlob(6);
                byte[] img = blob.getBytes(1, (int) blob.length());
                BufferedImage imagem = null;

                try {
                    imagem = ImageIO.read(new ByteArrayInputStream(img));
                } catch (Exception e) {
                    System.out.println(e);
                }
                ImageIcon icone = new ImageIcon(imagem);
                Icon foto = new ImageIcon(icone.getImage().getScaledInstance(LBfotousuario.getWidth(),
                        LBfotousuario.getHeight(), Image.SCALE_SMOOTH));
                LBfotousuario.setIcon(foto);

            } else {
                JOptionPane.showMessageDialog(null, "Foto não cadastrada!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }
     public ArrayList<admin> PesquisarAdmin(){
        String sql = "select * from admin";
        
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
           ResultSet res = stmt.executeQuery();
           
           while(res.next()){
               admin admin = new admin();
               admin.setId(res.getInt("id"));
               admin.setLogin(res.getString("login"));
               admin.setSenha(res.getString("senha"));
               admin.setEmail(res.getString("email"));
               admin.setTelefone(res.getString("telefone"));
               lista.add(admin);
           }
            
        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "FuncionarioDAO Pesquisa" + erro);
            
        }
        return lista;
     }  
     
     public boolean CheckLogin(String login, String senha){
         Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;
         
           boolean check = false;
       try{
           stmt = con.prepareStatement("SELECT * FROM admin WHERE login = ? and senha = ?");
           stmt.setString(1, login);
           stmt.setString(2, senha);
           rs = stmt.executeQuery();
           
           if (rs.next()){
               
               check = true;
               
           }
           
           while (rs.next()){
               admin admin = new admin();
               admin.setLogin(rs.getString("login"));
               admin.setSenha(rs.getString("senha"));
           }
       } catch (SQLException ex){
           Logger.getLogger(AdmintD.class.getName()).log(Level.SEVERE,null, ex);
       } finally {
           ConnectionFactory.closeConnection(con, stmt, rs);
       }
      return check;
     }
     public boolean CheckEmail(String email){
         Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;
         
           boolean check = false;
       try{
           stmt = con.prepareStatement("SELECT * FROM admin WHERE email=?");
           stmt.setString(1, email);
          
           rs = stmt.executeQuery();
           
           if (rs.next()){
               
               check = true;
               
           }
           
           while (rs.next()){
               admin admin = new admin();
               admin.setLogin(rs.getString("email"));
 
           }
       } catch (SQLException ex){
           Logger.getLogger(AdmintD.class.getName()).log(Level.SEVERE,null, ex);
       } finally {
           ConnectionFactory.closeConnection(con, stmt, rs);
       }
      return check;
        }

    public boolean CheckEmail(String text, String text0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     public void excluiradmin(admin admin){
    String sqli = "delete from admin where id=?";
    
      try {
    stmt = con.prepareStatement(sqli);
    stmt.setInt(1,admin.getId());
    stmt.execute();
    stmt.close();
} catch(SQLException erro){
    JOptionPane.showMessageDialog(null,"deu merda"+erro);
    
}
     }
}




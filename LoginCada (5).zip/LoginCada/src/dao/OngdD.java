 package dao;

import factory.ConnectionFactory;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import modelo.ong;
import java.sql.*;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import modelo.admin;
//Declaração de variaveis/

public class OngdD {
    Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;

    private Connection connection;
    ArrayList<ong> lista = new ArrayList<>();
    Long id;
    String nomeong;
    String endereço;
    String email;
    String telefone;
    //Puxando metodo de conexão/

    public OngdD() {
        this.connection = new ConnectionFactory().getConnection();

    }

    //Declarando string com uma query em MYSQL
    public void adiciona(ong ong) {
        String sql = "INSERT INTO ong(nome,endereco,telefone,email) VALUES(?,?,?,?)";
        //Resgatando metodos get do modelo/
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, ong.getNomeong());
            stmt.setString(2, ong.getEndereço());
            stmt.setString(3, ong.getTelefoneong());
            stmt.setString(4, ong.getEmailong());
            stmt.execute();
            stmt.close();
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
     public void buscarimagem(JLabel LBfotousuario, String id) {
        String sql = "select * from ong where id = ? ";

        try {
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setString(1, id);
            ResultSet res = stmt.executeQuery();

        if (res.next()) {
                Blob blob = (Blob) res.getBlob(6);
                byte[] img = blob.getBytes(1, (int) blob.length());
                BufferedImage imagem = null;

                try {
                    imagem = ImageIO.read(new ByteArrayInputStream(img));
                } catch (Exception e) {
                    System.out.println(e);
                }
                ImageIcon icone = new ImageIcon(imagem);
                Icon foto = new ImageIcon(icone.getImage().getScaledInstance(LBfotousuario.getWidth(),
                        LBfotousuario.getHeight(), Image.SCALE_SMOOTH));
                LBfotousuario.setIcon(foto);

            } else {
                JOptionPane.showMessageDialog(null, "Foto não cadastrada!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }
      public ArrayList<ong> Pesquisarong(){
        String sql = "select * from ong";
        
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
           ResultSet res = stmt.executeQuery();
           
           while(res.next()){
               ong ong = new ong();
               ong.setId(res.getInt("id"));
               ong.setNomeong(res.getString("nome"));;
               ong.setEndereço(res.getString("endereco"));;
               ong.setTelefoneong(res.getString("telefone"));;
               ong.setEmailong(res.getString("email"));;
       
               lista.add(ong);
           }
            
        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "FuncionarioDAO Pesquisa" + erro);
            
        }
        return lista;
     }
       public void excluirong(ong ong){
    String sqli = "delete from ong where id=?";
    
      try {
    stmt = con.prepareStatement(sqli);
    stmt.setInt(1,ong.getId());
    stmt.execute();
    stmt.close();
} catch(SQLException erro){
    JOptionPane.showMessageDialog(null,"deu merda"+erro);
    
}
     }


}

 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import modelo.Advogado;
import modelo.Doação;
import modelo.admin;

/**
 *
 * @author Aluno
 */
public class DoaçãoD {
    Connection con = ConnectionFactory.getConnection();
         PreparedStatement stmt = null;
         ResultSet rs = null;
     private Connection connection;
     ArrayList<Doação> lista = new ArrayList<>();
    Long id;
    String tipodedoação;
    String quantidadoação;
    String origemdoação;
    String caminhofoto;
      private FileInputStream fis;
    private int tamanho;


public DoaçãoD (){
 this.connection = new ConnectionFactory().getConnection();
}
 public void adiciona(Doação doação) {
        String sql = "INSERT INTO doação(tipodedoação,quantidadedoação,origemdoação,fotodoacao) VALUES(?,?,?,?)";
        //Resgatando metodos get do modelo/
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, doação.getTipodedoação());
            stmt.setString(2, doação.getQuantidadedoação());
            stmt.setString(3, doação.getOrigemdoação());
            stmt.setBlob(5, fis, tamanho);    
            
            stmt.execute();
            stmt.close();
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
  public void buscarimagem(JLabel LBfotousuario, String id) {
        String sql = "select * from doacao where id = ? ";

        try {
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setString(1, id);
            ResultSet res = stmt.executeQuery();

        if (res.next()) {
                Blob blob = (Blob) res.getBlob(5);
                byte[] img = blob.getBytes(1, (int) blob.length());
                BufferedImage imagem = null;

                try {
                    imagem = ImageIO.read(new ByteArrayInputStream(img));
                } catch (Exception e) {
                    System.out.println(e);
                }
                ImageIcon icone = new ImageIcon(imagem);
                Icon foto = new ImageIcon(icone.getImage().getScaledInstance(LBfotousuario.getWidth(),
                        LBfotousuario.getHeight(), Image.SCALE_SMOOTH));
                LBfotousuario.setIcon(foto);

            } else {
                JOptionPane.showMessageDialog(null, "ID não cadastrada!");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ta sem foto");
        }

    }
  public ArrayList<Doação> PesquisarDoação(){
        String sql = "select * from doacao";
        
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
           ResultSet res = stmt.executeQuery();
           
           while(res.next()){
               Doação Doação = new Doação();
               Doação.setId(res.getInt("id"));
               Doação.setTipodedoação(res.getString("tipodedoacao"));
               Doação.setOrigemdoação(res.getString("quantidadedoacao"));
               Doação.setQuantidadoação(res.getString("origemdoacao"));
               
               lista.add(Doação);
           }
            
        } catch (SQLException erro){
            JOptionPane.showMessageDialog(null, "FuncionarioDAO Pesquisa" + erro);
            
        }
        return lista;
     }
  public void excluirdoaçaao(Doação doaçao){
    String sqli = "delete from doacao where id=?";
    
      try {
    stmt = con.prepareStatement(sqli);
    stmt.setInt(1,doaçao.getId());
    stmt.execute();
    stmt.close();
} catch(SQLException erro){
    JOptionPane.showMessageDialog(null,"deu merda"+erro);
    
}
     }
}
